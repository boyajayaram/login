var userModel = require('../models/userModel')

module.exports.getDataFromDBService = ()=>{
    return new Promise(function checkURL(resolve,reject){
        userModel.find({},function returnData(error,result){
            if(error){
                reject(false)
            }
            else{
                resolve(result)
            }
        }
            )


    });
}

module.exports.updateUserDBService = (id,userDetails) => {
    console.log(userDetails)
    return new Promise(function myFn(resolve,reject){
       userModel.findByIdAndUpdate(id,userDetails,function returnData(error,result){

        if(error){
            reject(false)
        }
        else{
             resolve(result)
        }
       }) 

    })
}

module.exports.removeUserDBService = (id) => {
    
    return new Promise(function myFn(resolve,reject){
       userModel.findByIdAnddelete(id,function returnData(error,result){

        if(error){
            reject(false)
        }
        else{
             resolve(result)
        }
       }) 

    })
}







module.exports.creatUserDBService = (userDetails) =>{

    return new Promise(function myFn(resolve,reject){

        var userModelData =  new userModel();

        userModelData.first_name = userDetails.first_name;
        userModelData.last_name = userDetails.last_name;
        userModelData.email = userDetails.email;
        userModelData.password = userDetails.password;
        
        userModelData.save(function resultHandle(error,result){
            if(error){
                reject(false)
            }
            else{
                resolve(true)
            }
        })
    })
}


