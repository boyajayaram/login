var express = require('express')
const router = express.Router();

var userController = require('../Controllers/userControllers')

router.route('/user/getAll').get(userController.getDatacontrollerfn)

router.route('/user/creat').post(userController.creatUserControllerfn)


router.route('/user/delete').delete(userController.deleteUserController)


module.exports = router;