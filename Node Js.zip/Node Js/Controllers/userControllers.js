var userService = require('../models/userServices')


var getDatacontrollerfn = async(req,res)=>{

    var employee = await userService.getDataFromDBService();
    res.send({"status" : true, data:employee})
}

var creatUserControllerfn = async (req,res) =>{
    console.log(req.body);
    var status = await userService.creatUserDBService(req.body);

    if(status) {
        res.send("status:true", "message : user Created Successfully")
    }else{
        res.send("status :false","message : user creation failed")
    }
}


var updateUserController = async (req,res) =>{
    console.log(req.params.id);
    console.log(req.body)
    var result = await userService.updateUserDBService(req.params.id,req.body);

    if (result){
        res.send({"status": true, "message": "user Updated"})
        
    }
    else{
        
        res.send({"status": false, "message": " Update failed"})
    }
}


var deleteUserController = async (req,res)=>{
    console.log(req,params.id)


var result = await userService.removeUserDBService(req.params.id)

if(result){
    res.send({"status:":true ,"message": "Deleted Succesfully"})
}
else{
    res.send({"status" :false, "message" : "deletion Failed"})
}
}

module.exports = { getDatacontrollerfn,creatUserControllerfn,updateUserController,deleteUserController}