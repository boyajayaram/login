var express = require('express')
var server = express();
var routes = require('./routes/userRoutes')
var   mongoose = require('mongoose')
const cors = require('cors')


server.use(cors())
mongoose.connect("mongodb://localhost:27017/est",{useNewUrlParser: true ,useUnifiedTopology : true},).then(()=>console.log("db connected"))
.catch((error)=> {console.log(error);})



server.use("user",require("./routes/userRoutes"))




server.get('/getRequest',(req,res)=>{

var employee = [{ fullname: "Hameed",email:"hameed@gmail.com",phonenumber:98855664,Designation:"developer"},
{fullname: "Bharath", email:"bharath@gmail.com",phonenumber:9542255664,Designation:"Manager"},
{fullname: "Naresh",email:"naresh@gmail.com",phonenumber:98546664,Designation:"Team Leader"},
{fullname: "Nithin",email:"nithin@gmail.com",phonenumber:988754664,Designation:"HR"},
]
console.log(employee)
res.send(employee)
})
server.post('/login',(req,res)=>{
    console.log(req+"hameed");
    res.send(req+"hameed")


})
server.post('/user',(req,res)=>{
    console.log(JSON.stringify(req))
      res.send(JSON.stringify(req))
})
server.listen(7000,()=>{
    console.log("started")
    

})



